# occ_package_test
#### packaging occ project test by JerryLiu


This package and its subpackages were created to enable easy sharing and importing of functions and code developed by students in the OCC Lab at Temple University under the supervision of Dr. Rebecca Beadling.

routines for climate model analysis to support the research in the ocean climate connections group at Temple University

The lab aims to emphasize the importance of sharing and crediting code. Please cite the package if used in any publications.

8742
